---
title: Installation
subtitle: Getting Started
---

# Installation

saf


# Links

- [../index.md](../index.md)
- [../index](../index)
- [../getting-started/installation.md](../getting-started/installation.md)
- [../getting-started/installation](../getting-started/installation)
- [#codex:document[getting-started/installation]](#codex:document[getting-started/installation])
- [#codex:project[blade-extensions]](#codex:project[blade-extensions])                                                
- [../../develop/links.md #codex:document[ getting-started/installation ]](../../develop/links.md#codex:document[getting-started/installation])
- [../../develop/links.md #codex:document[ develop, links]](../../develop/links.md#codex:document[develop,links]) 
- [../../develop/links.md #codex:document[ codex,develop, getting-started/installation ]](../../develop/links.md#codex:document[codex,develop,getting-started/installation])    
- [../getting-started/installation.md #codex:document[ getting-started/installation ]](../getting-started/installation.md#codex:document[getting-started/installation])


