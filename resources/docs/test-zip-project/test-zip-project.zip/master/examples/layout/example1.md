---
title: Example 1
subtitle: Layout Examples
layout:
    left:
        outside: true

---

# Example 1

## Document Attributes

```yaml
title: Example 1
subtitle: Layout Examples
layout:
    left:
        outside: true
```
